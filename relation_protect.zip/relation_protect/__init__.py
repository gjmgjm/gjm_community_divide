#!/usr/bin/env python  
# encoding: utf-8  

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: __init__.py.py 
@time: 2018/3/29 10:18 
"""


def func():
    pass


class Main():
    def __init__(self):
        pass


if __name__ == "__main__":
    pass  