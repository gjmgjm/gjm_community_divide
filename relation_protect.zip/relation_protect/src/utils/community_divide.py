#!/usr/bin/env python  
# encoding: utf-8  

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: 3_sim_formula.py 
@time: 2019/1/20 15:39 
"""

import pandas as pd
from joblib import Parallel, delayed
import multiprocessing
import time
import math
import copy
from copy import deepcopy
from data_process import data_process
from itertools import combinations
import gc
import numpy as np
from protect_comloc import protect_comloc


def avg_similarity(u_neb_sim, u):  # 计算社区中用户u与其他用户的平均位置访问频率相似度
    sim = u_neb_sim.mean()
    return [u, sim]


def find_temp_pairs(u1, u2, temp):
    return [u1, u2, temp[0]]


class community_divide():
    def __init__(self):
        pass

    # path="G:/pyfile/relation_protect/src/data/city_data/"
    def set_checkins(self, path, city):
        data_processor = data_process()
        data_processor.set_basic_info(path, city)
        data_processor.user_pairs()
        self.pairs_path = data_processor.pairs_path
        self.path = data_processor.path
        self.city = data_processor.city
        users = data_processor.checkins.uid.unique().tolist()
        users.sort(reverse=False)
        self.users = np.array(deepcopy(users))  # 将用户的id进行从大到小的排序
        del users
        gc.collect()
        self.checkins = data_processor.checkins
        print("城市用户数为：", len(self.users))

    def run(self, m):
        community_divide_count = pd.DataFrame(self.user_cluster_list["clusterId"].value_counts()).reset_index()
        community_divide_count.columns = ['clusterId', 'nums']
        community_divide_count = community_divide_count[community_divide_count.nums != m].reset_index(drop=True)
        community_divide_count_LACK = community_divide_count[community_divide_count.nums < m].reset_index(drop=True)
        if (len(community_divide_count) == 1 and len(community_divide_count_LACK) == 1) or len(community_divide_count) == 0:
            return True
        # 进行首尾合并
        j = len(community_divide_count)
        for i in range(len(community_divide_count)):
            j = j - 1
            header_clusterId = community_divide_count.loc[i, 'clusterId']
            if i > j:
                break
            tail_clusterid = community_divide_count.loc[j, 'clusterId']
            uids = list(self.user_cluster_list[self.user_cluster_list.clusterId == tail_clusterid].uid.values)
            for u in uids:
                self.user_cluster_list.loc[self.user_cluster_list.uid == u, 'clusterId'] = header_clusterId
        community_divide_count = pd.DataFrame(self.user_cluster_list["clusterId"].value_counts()).reset_index()
        community_divide_count.columns = ['clusterId', 'nums']
        # print(community_divide_count)

        # 进行划分，将社区内用户数大于l的划分成几个子列表
        community_divide_count_numover = community_divide_count[community_divide_count.nums > m]
        for row in community_divide_count_numover.itertuples(index=False, name=False):  # 社区中用户个数大于l的社区进行均匀划分
            uids = list(self.user_cluster_list[self.user_cluster_list.clusterId == row[0]].uid.values)
            nums = int(math.floor(len(uids) / m))  # 可以划分的个数
            i_list = list(map(lambda x: x * m, range(nums)))
            for i in i_list:
                uids_temp = uids[i:(i + m)]
                self.clusterId += 1
                for u in uids_temp:
                    self.user_cluster_list.loc[self.user_cluster_list.uid == u, 'clusterId'] = self.clusterId
                del uids_temp[-len(uids_temp):0]
        return False

    def community_divide_core(self, m, n, method, k=-1):
        from comloc_similarity import comloc_similarity
        from cal_similarity import cal_similarity
        clusterId = 0   # 初始聚类号
        user_cluster_list = []  # 用于记录每个用户可能属于的聚类，以及在聚类中与其他用户的平均相似度，格式为[user,[cluserIds],clusterId,[cluster_sims]]
        for user in self.users:
            tmp = [user, [], 0, []]
            user_cluster_list.append(tmp)
        user_cluster_list = pd.DataFrame(user_cluster_list, columns=["uid", "clusterIds", "clusterId", "cluster_sims"])

        # 1.计算需要用到的特征相似度
        # if method == "comloc":  # 共同访问位置
        #     comloc_similarity = comloc_similarity()
        #     comloc_similarity.set_checkins(self.checkins, self.city)
        #     self.u1_u2_sim = comloc_similarity.cal_user_pairs()
        #     self.u1_u2_sim.to_csv(self.pairs_path + self.city + "_comloc.similarity", index=False, header=False)
        # elif method == "freqloc":  # 频繁访问位置
        #     cal_similarity = cal_similarity()
        #     cal_similarity.set_checkins(self.checkins, self.city)
        #     self.u1_u2_sim = cal_similarity.cal_freqloc_user_pairs(k)
        #     self.u1_u2_sim.to_csv(self.pairs_path + self.city + "_freqloc.similarity", index=False, header=False)
        # else:                      # 位置访问频率分布
        #     cal_similarity = cal_similarity()
        #     cal_similarity.set_checkins(self.checkins.values.tolist(), self.city, 20, [29.816691, -95.456244, 29.679229, -95.286390])
        #     self.u1_u2_sim = cal_similarity.cal_user_pairs()
        #     self.u1_u2_sim.to_csv(self.pairs_path + self.city + "_freqscatter.similarity", index=False, header=False)

        self.u1_u2_sim = pd.read_csv(self.pairs_path + self.city + "_" + method + ".similarity", names=["u1", "u2", "similarity"], header=None)
        print("第一步：开始计算每个用户可以属于的聚类")
        # print(len(self.users))
        u1_u2_sim = copy.deepcopy(self.u1_u2_sim).set_index(["u1", "u2"])   # 将相似度的u1和u2作为索引，取值更方便,并且不改变原有值数据框

        # 2.计算每个用户可以属于的聚类,m为内部参数用来判定用户的邻居 ,用户隐私需求参数 n
        checkin_cnt = 0
        checkin_chunk_size = int(len(self.users) / 10)
        for user in self.users:
            # print(clusterId)
            if checkin_cnt % checkin_chunk_size == 0:  # finished the anonymization of a chunk of checkins打印一部分匿名化的结果
                print('%-3d%% work complete.' % (int(checkin_cnt / checkin_chunk_size) * 10))
            # desclist = 0
            user_k_users = copy.deepcopy(self.u1_u2_sim[((self.u1_u2_sim.u1 == user) | (self.u1_u2_sim.u2 == user))])
            user_k_users = user_k_users.sort_values(by=["similarity"], ascending=False).reset_index(drop=True)  #按照亲密度进行降序排序
            user_sim_users = copy.deepcopy(user_k_users[user_k_users.similarity >= m])  # 选取亲密度>=m的用户对记录
            t = math.ceil(1 / n)    # 用户隐私需求社区中至少包含t个用户
            user_sim_users_num = len(user_sim_users)
            user_checkins = copy.deepcopy(self.checkins[self.checkins.uid == user])  # 用户user访问过的记录
            print("用户", user, "的邻居数量为", len(user_sim_users))
            if t > user_sim_users_num+1:    # 如果用户邻居个数不满足用户的隐私需求,需要添加虚假用户
                lack_user_num = t - user_sim_users_num-1  # 至少要添加的虚假用户的个数
                # print("需要添加的用户数为", lack_user_num)
                # print(user)
                extra_uid = user_k_users[user_sim_users_num:user_sim_users_num+lack_user_num]  # 取相似度在
                extra_uid_list = list((set.union(set(extra_uid['u1'].values), set(extra_uid['u2'].values))))
                extra_uid_list.remove(user)    # 得到添加的虚假用户的uid,为每一位虚假用户添加当前用户user的签到记录user_checkins
                for uid in extra_uid_list:     # 向原始数据集中添加虚假用户的签到记录
                    # desclist += 1
                    user_checkins.loc[:, 'uid'] = uid
                    self.checkins = pd.concat([self.checkins, user_checkins], ignore_index=True)
                    self.checkins.reset_index(drop=True)
                user_sim_users = pd.concat([user_sim_users, extra_uid], ignore_index=True)  # 将虚假用户对添加到当前社区中
                user_sim_users = user_sim_users.reset_index(drop=True)
                # print("需要添加虚假的用户个数为：", desclist)
            user_list = list((set.union(set(user_sim_users['u1'].values), set(user_sim_users['u2'].values))))
            user_list.sort(reverse=False)   # 先将用户uid进行排序,是的后面按照索引进行取值时能够获取指定用户对的相似度
            # print("社区", str(clusterId), "用户数为：", len(user_list))
            core_num = multiprocessing.cpu_count()
            temp_pairs = list(combinations(user_list, 2))
            temp_pairs = pd.DataFrame(temp_pairs, columns=['u1', 'u2'])
            temp_pairs_sim = Parallel(n_jobs=core_num)(delayed(find_temp_pairs)(temp_pairs.loc[i, 'u1'], temp_pairs.loc[i, 'u2'], (u1_u2_sim.xs(temp_pairs.loc[i, 'u1'])).xs(temp_pairs.loc[i, 'u2'])) for i in range(len(temp_pairs)))
            temp_pairs_sim = pd.DataFrame(temp_pairs_sim, columns=['u1', 'u2', 'similarity'])
            user_cluster_avgsim = Parallel(n_jobs=core_num)(delayed(avg_similarity)(temp_pairs_sim.loc[(temp_pairs_sim.u1 == u) | (temp_pairs_sim.u2 == u), 'similarity'], u) for u in user_list)
            user_cluster_avgsimlist = pd.DataFrame(user_cluster_avgsim, columns=['uid', 'avg_sim'])  # 得到每个用户在当前社区中与其他用户之间平均相似度
            for u1 in user_list:
                sim = user_cluster_avgsimlist[user_cluster_avgsimlist.uid == u1].avg_sim.values[0]
                index_num = user_cluster_list[user_cluster_list.uid == u1].index.values[0]
                user_cluster_list.iloc[index_num, 1].append(clusterId)
                user_cluster_list.iloc[index_num, 3].append(sim)
            clusterId += 1
            checkin_cnt += 1

        # self.checkins = self.checkins.ix[:, [0, 1, 2, 3, 4]]  # 保留用户id，time，lat,lng, locid数据
        self.checkins.to_csv("G:/pyfile/relation_protect/src/data/result_data/"+self.city+"_" + method + "_" + str(math.ceil(1 / n)) + "_user_community.data", index=False, sep='\t', header=False)

        # 释放内存
        del self.u1_u2_sim
        del u1_u2_sim
        gc.collect()

        print("第二步：开始把每个用户合并到某个具体的社区中")
        # 3.将用户具体划分到某一个社区中
        for i in range(len(user_cluster_list)):
            user_clusterIds = user_cluster_list.iloc[i, 1]
            user_cluster_simlist = user_cluster_list.iloc[i, 3]
            max_clusterid = user_clusterIds[user_cluster_simlist.index(max(user_cluster_simlist))]
            user_cluster_list.iloc[i, 2] = max_clusterid
        user_cluster_list.to_csv("G:/pyfile/relation_protect/src/data/city_data/"+self.city+"_" + method + "_" + str(math.ceil(1 / n)) + "_user_cluster_list", sep='\t',
                                 header=False, index=False)

        # 4. 将社区中用户数量小于l的用户进行合并
        print("第三步：将社区中用户数量分布均为l个满足安全性")
        self.clusterId = clusterId
        self.user_cluster_list = copy.deepcopy(user_cluster_list).ix[:, [0, 2]]
        del user_cluster_list
        gc.collect()
        t = math.ceil(1 / n)   # 社区用户数
        while True:
            flag = self.run(t)
            if flag is True:
                break
        self.user_cluster_list.to_csv("G:/pyfile/relation_protect/src/data/city_data/"+self.city+"_" + str(math.ceil(1 / n)) + "_simple_user_cluster_list", sep='\t',
                                 header=False, index=False)

        # 5. 将用户的社区id进行替换(或者加上社区id)
        print("第四步，原始数据加上社区id并保存匿名数据")
        self.checkins.loc[:, 'clusterid'] = -1   # 先为添加虚假用户后的数据添加社区id
        for row in self.user_cluster_list.itertuples(index=False, name=False):
            self.checkins.loc[self.checkins.uid == row[0], 'clusterid'] = row[1]  # 添加真正的社区id
        # 保存社区划分之后的数据
        self.checkins.to_csv("G:/pyfile/relation_protect/src/data/result_data/" + self.city + "_" + method + "_" + str(
            math.ceil(1 / n)) + "_user_simple_community.data", index=False, sep='\t', header=False)

        # 6. 对社区中的数据进行特征扰动
        if method == "comloc":  # 共同访问位置
            pc = protect_comloc(int(t), "comloc")
            pc.comnunity_disturb(self.checkins, 3, 0.6)
        elif method == "freqloc":  # 频繁访问位置
            pass
        else:                      # 位置访问频率分布
            pass


if __name__ == "__main__":
    start = time.time()
    for i in [0.35, 0.3, 0.2, 0.19, 0.15, 0.13, 0.12, 0.1]:
        start1 = time.time()
        test_case = community_divide()
        test_case.set_checkins("G:/pyfile/relation_protect/src/data/city_data/", "1")
        test_case.community_divide_core(0.54, i, "comloc")
        print(str(time.time()-start1))
    end = time.time()
    print(str(end-start))
    pass  