#!/usr/bin/env python
# encoding: utf-8

import pandas as pd
from grid_divide import grid_divide
import time


class random_disturb_security():

    def __init__(self):
        self.checkin_obf = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1.csv", delimiter="\t", index_col=None)
        self.checkin_obf = self.checkin_obf.values.tolist()
        self.checkin_obf = grid_divide(self.checkin_obf, 30, 40, [30.387953, -97.843911, 30.249935, -97.635460]).divide_area_by_NN()

    def cal_security(self, k):

        print(k)
        from security import security
        security = security()
        checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/1_" + str(k) + "_random_disturb.checkin", delimiter="\t", names=['uid', 'time', 'latitude', 'longitude', 'locid', 'num'], header=None)
        security.set_checkins(checkin, self.checkin_obf, "G:/pyfile/relation_protect/src/data/city_data/", str(k))
        b = security.b_security(4)
        c = security.c_security(100)
        d = security.d_security()
        e = security.e_security()
        security.all_security(0, b, c, d, e, 1/3, 1/3, 1/3)
        file = open("G:/pyfile/relation_protect/src/data/result_data/random_disturb_result.txt",  'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(k) + ' ' + 'b:' + str(b) + ' ' + 'c:' + str(c) + ' ' + 'd:' + str(d) + ' ' + 'e:' + str(e) +'\n')
        file.close()
        # a = security.a_security()
        # security.all_security(a, b, c, d, e, 1/3, 1/3, 1/3)

    def cal_utility(self, k):
        print()
        print(k)
        from utility import utility
        utility = utility()
        checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/1_" + str(k) + "_random_disturb.checkin",
                              delimiter="\t", names=['uid', 'time', 'latitude', 'longitude', 'locid', 'num'],
                              header=None)
        checkin.drop("num", axis=1, inplace=True)
        utility.set_checkins(checkin, self.checkin_obf, "G:/pyfile/relation_protect/src/data/city_data/", "G:/pyfile/relation_protect/src/data/result_data/", "1", str(k) + "_random_", "random_disturb")
        utility.checkin_sim_list2()
        k_utility = utility.sim_utility1(0.54)
        file = open("G:/pyfile/relation_protect/src/data/result_data/random_disturb_result.txt",  'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(k) + ' ' + str(k_utility) + '\n')
        file.close()


if __name__ == "__main__":
    start = time.time()
    for k in [10, 20, 30, 40, 50, 60, 70, 80]:
    # for k in [10]:
        random_disturb = random_disturb_security()
        # random_disturb.cal_security(k)
        random_disturb.cal_utility(k)
    end = time.time()
    print("总共花的费时间为", str(end-start))