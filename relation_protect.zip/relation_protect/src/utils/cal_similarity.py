#!/usr/bin/env python
# encoding: utf-8

from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
from joblib import Parallel, delayed
import multiprocessing
from itertools import combinations
from grid_divide import grid_divide
from copy import deepcopy
import time
import gc
import numpy as np


def freqdistbt_similarity(u1_vector, u2_vector, u1, u2):  # 位置访问频率分布相似度
    u1_u2_similarity = cosine_similarity([u1_vector], [u2_vector])
    return [str(u1), str(u2), u1_u2_similarity[0][0]]


def freqloc_similarity(u1_checkins, u2_checkins, u1, u2, k):  # 频繁访问位置相似度
    # u1_checkins, u2_checkins = self.checkins[self.checkins.uid == u1], self.checkins[self.checkins.uid == u2]
    u1_freq_locids = pd.DataFrame(u1_checkins['locid'].value_counts()).reset_index()  # 统计用户u1的locid及访问次数
    u1_freq_locids.columns = ['locid', 'cnt']
    u2_freq_locids = pd.DataFrame(u2_checkins['locid'].value_counts()).reset_index()  # 统计用户u2的locid及访问次数
    u2_freq_locids.columns = ['locid', 'cnt']
    if k > len(u1_freq_locids):
        u1_freq_locids = u1_freq_locids[0:k]
    if k > len(u2_freq_locids):
        u2_freq_locids = u2_freq_locids[0:k]
    itstlistlen = len(list(set(u1_freq_locids['locid'].values).intersection(set(u2_freq_locids['locid'].values))))
    return [str(u1), str(u2), itstlistlen]


class cal_similarity():

    def __init__(self):
        pass

    def set_checkins(self, checkins, city, n=0, m=0, ranges=None):
        self.checkins = checkins  # 不需要进行网格划分，利用的特征是频繁访问位置或者共同访问位置特征
        if ranges is not None:     # 表示需要进行网格划分，利用的特征是位置访问频率分布
            grid_divider = grid_divide(deepcopy(checkins), n, m, ranges)
            checkin = grid_divider.divide_area_by_NN()
            self.checkins = checkin.ix[:, [0, 1, 2, 3, 4, 5]]
            self.grid_id = list(self.checkins.grid_id.unique())
        self.city = city
        users = self.checkins.uid.unique().tolist()
        users.sort(reverse=False)
        self.users = np.array(deepcopy(users))  # 将用户的id进行从大到小的排序
        del users
        gc.collect()

    def cal_user_vector(self, u_checkins, u):
        u_vector = list(map((lambda x: len(u_checkins[u_checkins.grid_id == x]) * 1.0 / len(u_checkins)), self.grid_id))
        return [u, u_vector]

    def cal_user_pairs(self):   # 位置访问频率分布相似度
        # 计算位置访问频率向量
        core_num = multiprocessing.cpu_count()
        loc_vector = Parallel(n_jobs=core_num)(
            delayed(self.cal_user_vector)(self.checkins[self.checkins.uid == u], u) for u in self.users)
        loc_vector = pd.DataFrame(loc_vector, columns=['uid', 'vector'])
        print("位置访问频率向量计算完成")
        # 计算用户对之间的位置访问频率相似度
        pairs = list(combinations(self.users, 2))
        pairs = pd.DataFrame(pairs, columns=['u1', 'u2'])
        meet_cell = Parallel(n_jobs=core_num)(
            delayed(freqdistbt_similarity)(loc_vector.loc[loc_vector.uid == pairs.loc[i, 'u1'], 'vector'].values[0],
                                           loc_vector.loc[loc_vector.uid == pairs.loc[i, 'u2'], 'vector'].values[0],
                                           pairs.loc[i, 'u1'], pairs.loc[i, 'u2']) for i in range(len(pairs)))
        pairs_sim_list = pd.DataFrame(meet_cell, columns=['u1', 'u2', 'similarity'])
        # pairs_sim_list.to_csv("G:/pyfile/relation_protect/src/data/city_data/"+self.city+"_freqscatter1.similarity", index=False, header=False)
        return pairs_sim_list

    def cal_freqloc_user_pairs(self, k):    # 频繁访问位置相似度
        # 计算出用户间的相似度值
        pairs = list(combinations(self.users, 2))
        pairs = pd.DataFrame(pairs, columns=['u1', 'u2'])
        print("用户对计算完成")
        core_num = multiprocessing.cpu_count()
        meet_cell = Parallel(n_jobs=core_num)(
            delayed(freqloc_similarity)(self.checkins[self.checkins.uid == pairs.iloc[i]['u1']], self.checkins[self.checkins.uid == pairs.iloc[i]['u2']], pairs.iloc[i]['u1'], pairs.iloc[i]['u2'], k) for i in range(len(pairs)))
        pairs_sim_list = pd.DataFrame(meet_cell, columns=['u1', 'u2', 'similarity'])
        print("频繁访问位置相似度计算完成")
        pairs_sim_list.to_csv("G:/pyfile/relation_protect/src/data/city_data/" + self.city + "_freqloc.similarity",
                              index=False, header=False)
        return pairs_sim_list


if __name__ == "__main__":
        start = time.time()
        cal_similarity = cal_similarity()
        checkins = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1.csv", delimiter="\t", index_col=None)
        cal_similarity.set_checkins(checkins.values.tolist(), "1", 30, 40, [30.387953, -97.843911, 30.249935, -97.635460])
        cal_similarity.cal_user_pairs()
        # cal_similarity.set_checkins(checkins, "1")
        # cal_similarity.cal_freqloc_user_pairs(4)
        end = time.time()
        print(str(end-start))