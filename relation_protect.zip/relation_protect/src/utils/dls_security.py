#!/usr/bin/env python
# encoding: utf-8

"""
@version: v1.0
@author: jaculamata
@license: Apache Licence
@contact: 819436557@qq.com
@site: http://blog.csdn.net/hqzxsc2006
@software: PyCharm
@file: 5_security.py
@time: 2019/1/20 15:44
"""
import pandas as pd
import time
from grid_divide import grid_divide
from joblib import Parallel, delayed
import multiprocessing
from scipy.special import comb
import numpy as np
from numpy.linalg import norm
from scipy.stats import entropy
from functools import reduce
from operator import add
import math
from itertools import combinations


class dls_security():

    def __init__(self):
        self.checkins_obf = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1.csv", delimiter="\t", index_col=None)
        self.checkins_obf = self.checkins_obf.values.tolist()
        self.checkins_obf = grid_divide(self.checkins_obf,  30, 40, [30.387953, -97.843911, 30.249935, -97.635460]).divide_area_by_NN()
        self.checkins_obf['grid_id'] = self.checkins_obf['grid_id'].astype(int)   # 将原始数据中的grid_id转换成int类型
        print("原始数据读取成功")

    # def a_security(self):
    #     locids_uids = self.checkins.groupby(by=['locid', 'uid']).size().reset_index(name='uid_nums')
    #     locisd_uids_obf = self.checkins_obf.groupby(by=['locid', 'uid']).size().reset_index(name='uid_nums')
    #
    #     uid_pairs = []  # 用户对
    #     uid_pairs_fres = []  # 用户对产生的个数
    #     checkin_cnt = 0
    #     checkin_chunk_size = int(len(self.checkins_obf.locid.unique()) / 10)
    #     # 剩下的进行统计
    #     for locid in self.checkins_obf.locid.unique():
    #         if checkin_cnt % checkin_chunk_size == 0:  # finished the anonymization of a chunk of checkins打印一部分匿名化的结果
    #             print('%-3d%% work complete.' % (int(checkin_cnt / checkin_chunk_size) * 10))
    #         locid_uids = locids_uids[locids_uids.locid == locid].uid.values
    #         locid_uids_obf = locisd_uids_obf[locisd_uids_obf.locid == locid].uid.values
    #         common_uids = list(set(locid_uids).intersection(set(locid_uids_obf)))
    #         if len(common_uids) > 1:
    #             locid_uid_pairs = list(combinations(common_uids, 2))
    #             for i in locid_uid_pairs:
    #                 if set(i) in uid_pairs:
    #                     uid_pairs_fres[uid_pairs.index(set(i))] += 1
    #                 else:
    #                     uid_pairs.append(set(i))
    #                     uid_pairs_fres.append(1)
    #         checkin_cnt += 1
    #     uid_pairs_fres_set = set(uid_pairs_fres)
    #     uid_pairs_freqs = list(map(lambda x: uid_pairs_fres.count(x), uid_pairs_fres_set))
    #     freqs_sum = sum(uid_pairs_freqs)
    #     uid_pairs_freqs = [freq / freqs_sum for freq in uid_pairs_freqs]
    #     print("a_security:", uid_pairs_freqs)
    #     q1 = entropy(uid_pairs_freqs)
    #     print(q1)
    #     return uid_pairs_freqs

    # def single_security(self, u1, u2):
    #     checkins = self.checkins
    #     checkins_obf = self.checkins_obf
    #     u1_checkin = checkins.loc[checkins.uid == u1]
    #     u1_checkin_obf = checkins_obf.loc[checkins_obf.uid == u1]
    #     u2_checkin = checkins.loc[checkins.uid == u2]
    #     u2_checkin_obf = checkins_obf.loc[checkins_obf.uid == u2]
    #     u1_locids = u1_checkin.locid.unique()
    #     u2_locids = u2_checkin.locid.unique()
    #     u1_locids_obf = u1_checkin_obf.locid.unique()
    #     u2_locids_obf = u2_checkin_obf.locid.unique()
    #     u1_u2_com_locids = set(u1_locids).intersection(set(u2_locids))
    #     u1_u2_com_locids_obf = set(u1_locids_obf).intersection(set(u2_locids_obf))
    #     if len(u1_u2_com_locids_obf) == 0:
    #         if len(u1_u2_com_locids) == 0:
    #             return 1
    #         else:
    #             return 0
    #     u1_u2_com = list(u1_u2_com_locids.intersection(u1_u2_com_locids_obf))
    #     return len(u1_u2_com) * 1.0 / len(u1_u2_com_locids_obf)

    # def a_security(self):
    #     start = time.time()
    #     print()
    #     print("用户间共同访问位置改变情况")
    #     pairs = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1" + ".pairs", names=["u1", "u2"], header=None)
    #     checkins_obf_uids = self.checkins_obf.uid.unique()
    #     # single_security = 0
    #     core_num = multiprocessing.cpu_count()
    #     meet_cell = Parallel(n_jobs=core_num)(delayed(self.single_security)(pairs.iloc[i]['u1'], pairs.iloc[i]['u2']) for i in range(len(pairs)))
    #     security = sum(meet_cell) / (comb(len(checkins_obf_uids), 2))
    #     # checkin_cnt = 0
    #     # checkin_chunk_size = int(len(pairs) / 10)
    #     # checkinid = 0
    #     # for row in pairs.itertuples(index=False, name=False):
    #     #     checkinid += 1
    #     #     if checkin_cnt % checkin_chunk_size == 0:  # finished the anonymization of a chunk of checkins打印一部分匿名化的结果
    #     #         print('%-3d%% work complete.' % (int(checkin_cnt / checkin_chunk_size) * 10))
    #     #     u1, u2 = row[0], row[1]
    #     #     u1_checkin = checkins.loc[checkins.uid == u1]  # u1的匿名签到记录
    #     #     u2_checkin = checkins.loc[checkins.uid == u2]  # u2的匿名签到记录
    #     #     u1_checkin_obf = checkins_obf.loc[checkins_obf.uid == u1]  # u1的原始记录
    #     #     u2_checkin_obf = checkins_obf.loc[checkins_obf.uid == u2]  # u2的原始记录
    #     #     u1_locids = u1_checkin.locid.unique()
    #     #     u2_locids = u2_checkin.locid.unique()
    #     #     u1_locids_obf = u1_checkin_obf.locid.unique()
    #     #     u2_locids_obf = u2_checkin_obf.locid.unique()
    #     #     u1_u2_com_locids = set(u1_locids).intersection(set(u2_locids))  # # u1和u2的匿名共同访问位置
    #     #     u1_u2_com_locids_obf = set(u1_locids_obf).intersection(set(u2_locids_obf))  # u1和u2的原始共同访问位置
    #     #     if len(u1_u2_com_locids_obf) == 0:
    #     #         if len(u1_u2_com_locids) == 0:
    #     #             single_security += 1
    #     #         else:
    #     #             single_security += 0
    #     #     else:
    #     #         u1_u2_com = list(u1_u2_com_locids.intersection(u1_u2_com_locids_obf))  # 保护前后u1和u2共同访问位置交集
    #     #         single_security += len(u1_u2_com) * 1.0 / len(u1_u2_com_locids_obf)
    #     #     checkin_cnt += 1
    #     # security = single_security/(comb(len(checkins_obf_uids), 2))
    #     end = time.time()
    #     print("总共花的费时间为", str(end - start))
    #     print("a:", security)
    #     return security

    def cal_security(self, k, method):
        from security import security
        print(k)
        security = security()
        checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/simple" + str(k) + "_ano_HCheckins.csv", delimiter="\t", names=["uid", "locid"], header=None)
        security.set_checkins(checkin, self.checkins_obf, "G:/pyfile/relation_protect/src/data/city_data/", str(k))
        b = security.b_security(4)
        c = security.c_security(100)
        d = security.d_security()
        e = security.e_security()
        security.all_security(0, b, c, d, e, 1 / 3, 1 / 3, 1 / 3)
        file = open("G:/pyfile/relation_protect/src/data/result_data/" + method + ".txt", 'a', encoding='UTF-8')
        file.write('比例参数:' + str(k) + ' ' + 'b:' + str(b) + ' ' + 'c:' + str(c) + ' ' + 'd:' + str(d) + ' ' + 'e:' + str(e) + '\n')
        file.close()
        # a = self.a_security()
        # self.all_security(a, b, c, d, e, 1/3, 1/3, 1/3)

    def cal_utility(self, k, method):
        from utility import utility
        print(k)
        utility = utility()
        checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/simple" + str(k) + "_ano_HCheckins2.csv",
                              delimiter="\t", names=["uid", "time", "latitude", "longitude", "locid"], header=None)
        utility.set_checkins(checkin, self.checkins_obf, "G:/pyfile/relation_protect/src/data/city_data/",
                             "G:/pyfile/relation_protect/src/data/result_data/", "1", str(k)+"_ano_", "dls")
        utility.checkin_sim_list2()
        k_utility = utility.sim_utility(0.54, k)
        file = open("G:/pyfile/relation_protect/src/data/result_data/" + method + ".txt", 'a', encoding='UTF-8')
        file.write('比例参数:' + str(k) + ' ' + 'utility:' + str(k_utility) + '\n')
        file.close()


if __name__ == "__main__":
    start = time.time()

    for k in [3, 4, 5, 6, 7, 8, 9, 10]:
        dls_se = dls_security()
        # dls_se.cal_security(str(k), "dls_result")
        dls_se.cal_utility(k, "dls_result")
    end = time.time()
    print("总共花的费时间为", str(end-start))
