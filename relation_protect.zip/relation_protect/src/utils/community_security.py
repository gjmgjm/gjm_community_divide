#!/usr/bin/env python
# encoding: utf-8

import time
import pandas as pd
from grid_divide import grid_divide


class commutity_security():

    def __init__(self):
        self.checkin_obf = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1.csv", delimiter="\t", index_col=None)
        self.checkin_obf = self.checkin_obf.values.tolist()
        self.checkin_obf = grid_divide(self.checkin_obf, 30, 40, [30.387953, -97.843911, 30.249935, -97.635460]).divide_area_by_NN()
        self.checkin_obf['grid_id'] = self.checkin_obf['grid_id'].astype(int)  # 将原始数据中的grid_id转换成int类型
        print("原始数据读取成功")

    def cal_security(self, k):
        print(k)
        from security import security
        security = security()
        # 1_freqscatter_4_user_community.data
        # 1_comloc_4_user_simple_community.data
        # 3_comloc.csv
        # checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/1_freqscatter_" + str(k) + "_user_simple_community.data", delimiter="\t",
        #                       names=["uid", "time", "latitude", "longitude", "locid", "clusterid"], header=None)
        checkin = pd.read_csv(
            "G:/pyfile/relation_protect/src/data/result_data/" + str(k) + "_comloc.csv",
            delimiter="\t", names=["uid", "time", "latitude", "longitude", "locid", "clusterid"], header=None)
        security.set_checkins(checkin, self.checkin_obf, "G:/pyfile/relation_protect/src/data/city_data/", str(k))
        b = security.b_security(4)
        c = security.c_security(100)
        d = security.d_security()
        e = security.e_security()
        security.all_security(0, b, c, d, e, 1 / 3, 1 / 3, 1 / 3)
        file = open("G:/pyfile/relation_protect/src/data/result_data/community_result.txt", 'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(k) + ' ' + 'b:' + str(b) + ' ' + 'c:' + str(c) + ' ' + 'd:' + str(d) + ' ' + 'e:' + str(e) + '\n')
        file.close()
        # a = security.a_security()
        # security.all_security(a, b, c, d, e, 1/3, 1/3, 1/3)

    def cal_utility(self, a, k):
        print()
        print(k)
        from utility import utility
        utility = utility()
        checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/1_comloc_" + str(k) + "_user_simple_community.data", delimiter="\t", names=["uid", "time", "latitude", "longitude", "locid", "clusterid"], header=None)
        # checkin = pd.read_csv(
        #     "G:/pyfile/relation_protect/src/data/result_data/" + str(k) + "_comloc.csv",
        #     delimiter="\t",
        #     names=["uid", "time", "latitude", "longitude", "locid", "clusterid"], header=None)
        checkin = checkin.ix[:, [0, 1, 2, 3, 4]]
        # utility.set_checkins(checkin, self.checkin_obf, "G:/pyfile/relation_protect/src/data/city_data/", "G:/pyfile/relation_protect/src/data/result_data/", "1", str(k) + "_community_", "comloc_divide_after")
        utility.set_checkins(checkin, self.checkin_obf, "G:/pyfile/relation_protect/src/data/city_data/",
                             "G:/pyfile/relation_protect/src/data/result_data/", "1", str(k) + "_community_",
                             "com_divide")

        utility.checkin_sim_list2()
        k_utility = utility.sim_utility(a, k)
        file = open("G:/pyfile/relation_protect/src/data/result_data/community_result.txt", 'a', encoding='UTF-8')
        file.write('扰动比例参数:' + str(k) + ' ' + str(k_utility) + '\n')
        file.close()


if __name__ == "__main__":
    start = time.time()
    for k in [3, 4, 5, 6, 7, 8, 9, 10]:
        commutity_se = commutity_security()
        # commutity_se.cal_security(str(k))
        commutity_se.cal_utility(0.54, k)
    end = time.time()
    print("总共花的费时间为", str(end-start))