#!/usr/bin/env python  
# encoding: utf-8  

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: 5_security.py 
@time: 2019/1/20 15:44 
"""
import pandas as pd
from numpy.linalg import norm
from scipy.stats import entropy
import numpy as np
from joblib import Parallel, delayed
import multiprocessing
from scipy.special import comb
from collections import Counter
import time
from functools import reduce
from operator import add
import math
from itertools import combinations


def JSD(P, Q):
    _P = P / norm(P, ord=1)
    _Q = Q / norm(Q, ord=1)
    _M = 0.5 * (_P + _Q)
    return 0.5 * (entropy(_P, _M, base=2) + entropy(_Q, _M, base=2))


class security():
    def __init__(self):
        pass

    def set_checkins(self, checkins, checkins_obf, pairs_path, city):
        self.checkins = checkins
        self.checkins_obf = checkins_obf
        self.pairs_path = pairs_path
        self.city = city
        self.uid_pairs_obf = []  # 用户对
        self.uid_pairs_fres_obf = []  # 用户对产生的个数
        print("保护前后数据读取成功")

    def security(self):
        locisd_uids_obf = self.checkins_obf.groupby(by=['locid', 'uid']).size().reset_index(name='uid_nums')
        for locid in self.checkins_obf.locid.unique():
            locid_uids_obf = locisd_uids_obf[locisd_uids_obf.locid == locid].uid.values
            if len(locid_uids_obf) > 1:  # 保护前用户对
                locid_uid_pairs_obf = list(combinations(locid_uids_obf, 2))
                for i in locid_uid_pairs_obf:
                    if set(i) in self.uid_pairs_obf:
                        self.uid_pairs_fres_obf[self.uid_pairs_obf.index(set(i))] += 1
                    else:
                        self.uid_pairs_obf.append(set(i))
                        self.uid_pairs_fres_obf.append(1)
        dict1 = {'pair': self.uid_pairs_obf, 'num': self.uid_pairs_fres_obf}
        data = pd.DataFrame(dict1, columns=['pairs', 'num'])
        data = data.sort_values(by=['num'], ascending=False).reset_index(drop=True)
        print(data)
        data.to_csv("G:/pyfile/relation_protect/src/data/result_data/ttt.csv", header=None, sep="\t")

    def a_security(self):
        print()
        print("用户间共同访问位置改变情况")
        locids_uids = self.checkins.groupby(by=['locid', 'uid']).size().reset_index(name='uid_nums')
        uid_pairs = []  # 用户对
        uid_pairs_fres = []  # 用户对产生的个数

        checkin_cnt = 0
        checkin_chunk_size = int(len(self.checkins_obf.locid.unique()) / 10)
        # 剩下的进行统计
        for locid in self.checkins_obf.locid.unique():
            if checkin_cnt % checkin_chunk_size == 0:  # finished the anonymization of a chunk of checkins打印一部分匿名化的结果
                print('%-3d%% work complete.' % (int(checkin_cnt / checkin_chunk_size) * 10))
            locid_uids = locids_uids[locids_uids.locid == locid].uid.values
            if len(locid_uids) > 1:       # 保护后用户对
                locid_uid_pairs = list(combinations(locid_uids, 2))
                for i in locid_uid_pairs:
                    if set(i) in uid_pairs:
                        uid_pairs_fres[uid_pairs.index(set(i))] += 1
                    else:
                        uid_pairs.append(set(i))
                        uid_pairs_fres.append(1)
            checkin_cnt += 1
        uid_pairs_fres_set = set(uid_pairs_fres)
        uid_pairs_freqs = list(map(lambda x: uid_pairs_fres.count(x), uid_pairs_fres_set))
        freqs_sum = sum(uid_pairs_freqs)
        uid_pairs_freqs = [freq / freqs_sum for freq in uid_pairs_freqs]
        print("a_security:", uid_pairs_freqs)
        q1 = entropy(uid_pairs_freqs)
        print(q1)
        return uid_pairs_freqs

    # def single_security(self, u1, u2):
    #     checkins = self.checkins
    #     checkins_obf = self.checkins_obf
    #     u1_checkin = checkins.loc[checkins.uid == u1]
    #     u1_checkin_obf = checkins_obf.loc[checkins_obf.uid == u1]
    #     u2_checkin = checkins.loc[checkins.uid == u2]
    #     u2_checkin_obf = checkins_obf.loc[checkins_obf.uid == u2]
    #     u1_locids = u1_checkin.locid.unique()
    #     u2_locids = u2_checkin.locid.unique()
    #     u1_locids_obf = u1_checkin_obf.locid.unique()
    #     u2_locids_obf = u2_checkin_obf.locid.unique()
    #     u1_u2_com_locids = set(u1_locids).intersection(set(u2_locids))
    #     u1_u2_com_locids_obf = set(u1_locids_obf).intersection(set(u2_locids_obf))
    #     u1_u2_com = list(u1_u2_com_locids.intersection(u1_u2_com_locids_obf))
    #     return [u1, u2, len(u1_u2_com)]
    #     # if len(u1_u2_com_locids_obf) == 0:
    #     #     if len(u1_u2_com_locids) == 0:
    #     #         return 1
    #     #     else:
    #     #         return 0
    #     # u1_u2_com = list(u1_u2_com_locids.intersection(u1_u2_com_locids_obf))
    #     # return len(u1_u2_com) * 1.0 / len(u1_u2_com_locids_obf)
    #
    # def a_security1(self):
    #     start = time.time()
    #     print()
    #     print("用户间共同访问位置改变情况")
    #     pairs = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1.pairs", names=["u1", "u2"], header=None)
    #     checkins_obf_uids = self.checkins_obf.uid.unique()
    #     # single_security = 0
    #     core_num = multiprocessing.cpu_count()
    #     meet_cell = Parallel(n_jobs=core_num)(delayed(self.single_security)(pairs.iloc[i]['u1'], pairs.iloc[i]['u2']) for i in range(len(pairs)))
    #     data = pd.DataFrame(meet_cell, columns=['u1', 'u2', 'com_locids_num'])
    #     data.to_csv("G:/pyfile/relation_protect/src/data/result_data/" + self.city + ".checkins", sep='\t', header=False, index=False)
    #     # result = data.groupby(by=['com_locids_num']).size().reset_index(name='times')
    #     # security = sum(meet_cell) / (comb(len(checkins_obf_uids), 2))
    #     # checkin_cnt = 0
    #     # checkin_chunk_size = int(len(pairs) / 10)
    #     # checkinid = 0
    #     # for row in pairs.itertuples(index=False, name=False):
    #     #     checkinid += 1
    #     #     if checkin_cnt % checkin_chunk_size == 0:  # finished the anonymization of a chunk of checkins打印一部分匿名化的结果
    #     #         print('%-3d%% work complete.' % (int(checkin_cnt / checkin_chunk_size) * 10))
    #     #     u1, u2 = row[0], row[1]
    #     #     u1_checkin = checkins.loc[checkins.uid == u1]  # u1的匿名签到记录
    #     #     u2_checkin = checkins.loc[checkins.uid == u2]  # u2的匿名签到记录
    #     #     u1_checkin_obf = checkins_obf.loc[checkins_obf.uid == u1]  # u1的原始记录
    #     #     u2_checkin_obf = checkins_obf.loc[checkins_obf.uid == u2]  # u2的原始记录
    #     #     u1_locids = u1_checkin.locid.unique()
    #     #     u2_locids = u2_checkin.locid.unique()
    #     #     u1_locids_obf = u1_checkin_obf.locid.unique()
    #     #     u2_locids_obf = u2_checkin_obf.locid.unique()
    #     #     u1_u2_com_locids = set(u1_locids).intersection(set(u2_locids))  # # u1和u2的匿名共同访问位置
    #     #     u1_u2_com_locids_obf = set(u1_locids_obf).intersection(set(u2_locids_obf))  # u1和u2的原始共同访问位置
    #     #     if len(u1_u2_com_locids_obf) == 0:
    #     #         if len(u1_u2_com_locids) == 0:
    #     #             single_security += 1
    #     #         else:
    #     #             single_security += 0
    #     #     else:
    #     #         u1_u2_com = list(u1_u2_com_locids.intersection(u1_u2_com_locids_obf))  # 保护前后u1和u2共同访问位置交集
    #     #         single_security += len(u1_u2_com) * 1.0 / len(u1_u2_com_locids_obf)
    #     #     checkin_cnt += 1
    #     # security = single_security/(comb(len(checkins_obf_uids), 2))
    #     end = time.time()
    #     print("总共花的费时间为", str(end - start))
    #     print("a:", security)
    #     return security

    def b_security(self, m):
        print()
        print("用户频繁访问位置改变情况")
        start = time.time()
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        single_security = 0
        checkins_obf_uids = checkin_obf.uid.unique()
        for u in checkin_obf.uid.unique():
            u_checkin = checkin.loc[checkin.uid == u]
            u_checkin_obf = checkin_obf.loc[checkin_obf.uid == u]
            u_loc_distr = pd.DataFrame(u_checkin['locid'].value_counts()).reset_index()  # 统计locid的不同值及其个数
            u_loc_distr.columns = ['locid', 'cnt']
            u_loc_distr_obf = pd.DataFrame(u_checkin_obf['locid'].value_counts()).reset_index()
            u_loc_distr_obf.columns = ['locid', 'cnt']
            if m <= len(u_loc_distr):
                u_loc_distr = u_loc_distr[0:m]
            if m <= len(u_loc_distr_obf):
                u_loc_distr_obf = u_loc_distr_obf[0:m]
            itstlist = list(set(u_loc_distr['locid'].values).intersection(set(u_loc_distr_obf['locid'].values)))
            single_security += len(itstlist) * 1.0/len(u_loc_distr_obf)
        security = single_security/len(checkins_obf_uids)
        end = time.time()
        print("总共花的费时间为", str(end - start))
        print("b:", security)
        return security

    def c_security(self, m):
        print()
        print("全局的频繁访问位置分布改变情况")
        start = time.time()
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        checkin_fre = pd.DataFrame(checkin['locid'].value_counts()).reset_index()
        checkin_fre.columns = ['locid', 'cnt']
        checkin_obf_fre = pd.DataFrame(checkin_obf['locid'].value_counts()).reset_index()
        checkin_obf_fre.columns = ['locid', 'cnt']
        checkin_fre = checkin_fre[0:m]
        checkin_obf_fre = checkin_obf_fre[0:m]
        itstlist = list(set(checkin_fre['locid'].values).intersection(set(checkin_obf_fre['locid'].values)))
        globle_security = len(itstlist) * 1.0 / len(checkin_obf_fre)
        end = time.time()
        print("总共花的费时间为", str(end - start))
        print("c:", globle_security)
        return globle_security

    def d_security(self):
        print()
        print("全局位置访问频率分布改变情况")   # 全局位置访问频率分布改变情况，保护前后访问频率分布分别为Ta,Tb
        start = time.time()
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        checkin_len = len(checkin)
        checkin_obf_len = len(checkin_obf)
        union_grid_id = list(set(checkin.locid.unique()).union(set(checkin_obf.locid.unique())))
        checkin_vec = list(map((lambda x: len(checkin[checkin.locid == x]) * 1.0 / checkin_len), union_grid_id))
        checkin_obf_vec = list(map((lambda x: len(checkin_obf[checkin_obf.locid == x]) * 1.0 / checkin_obf_len),union_grid_id))
        checkin_vec = np.array(list(checkin_vec))
        checkin_obf_vec = np.array(list(checkin_obf_vec))
        globle_security = JSD(checkin_vec, checkin_obf_vec)
        end = time.time()
        print("总共花的费时间为", str(end - start))
        print("d:", globle_security)
        return globle_security

    def e_security(self):
        print()
        print("用户位置访问频率分布改变情况")
        checkin = self.checkins
        checkin_obf = self.checkins_obf
        single_security = 0
        for u in checkin_obf.uid.unique():
            u_checkin = checkin.loc[checkin.uid == u]
            u_checkin_obf = checkin_obf.loc[checkin_obf.uid == u]
            u_checkin_len = len(u_checkin)
            u_checkin_obf_len = len(u_checkin_obf)
            union_grid_id = list(set(u_checkin.locid.unique()).union(set(u_checkin_obf.locid.unique())))
            checkin_vec = list(map((lambda x: len(u_checkin[u_checkin.locid == x]) * 1.0 / u_checkin_len), union_grid_id))
            checkin_obf_vec = list(map((lambda x: len(u_checkin_obf[u_checkin_obf.locid == x]) * 1.0 / u_checkin_obf_len), union_grid_id))
            single_security += JSD(np.array(checkin_vec), np.array(checkin_obf_vec))
        print("e:", single_security/len(checkin_obf.uid.unique()))
        return single_security/len(checkin_obf.uid.unique())

    def entropy(self, probabilities):
        return -reduce(add, map(lambda x: math.log2(x) * x, probabilities))

    def all_security(self, a, b, c, d, e, m, n, r):
        # Q1 = self.entropy(a)
        Q2 = self.entropy([b/(b+c), c/(b+c)])
        print("q2:", Q2)
        Q3 = self.entropy([d/(d+e), e/(d+e)])
        print("q3:", Q3)
        # expose_entropy = m * Q1 + n * Q2 + r * Q3
        # print("expose_entropy", expose_entropy)
        # return expose_entropy

