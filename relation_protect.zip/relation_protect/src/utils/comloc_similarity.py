#!/usr/bin/env python
# encoding: utf-8

from sklearn.metrics.pairwise import cosine_similarity
import pandas as pd
from joblib import Parallel, delayed
import multiprocessing
from itertools import combinations
import time
import gc
import numpy as np
from copy import deepcopy


def comloc_similaritys(u1_vector, u2_vector, u1, u2):
    u1_u2_similarity = cosine_similarity([u1_vector], [u2_vector])
    return [str(u1), str(u2), u1_u2_similarity[0][0]]


class comloc_similarity():
    def __init__(self):
        pass

    def set_checkins(self, checkins, city):
        self.checkins = checkins
        self.city = city
        users = self.checkins.uid.unique().tolist()
        users.sort(reverse=False)
        self.users = np.array(deepcopy(users))   #将用户的id进行从大到小的排序
        del users
        gc.collect()

    def comloc_meet(self, u1_checkins, u1):
        checkins = self.checkins
        comloc_nums = []
        u1_locids = u1_checkins.locid.unique()
        # print(u1)
        # 可用内置函数进行改写，速度应该会快一点
        for u in self.users:
            u_checkins = checkins[checkins.uid == u]
            comloc_nums.append(len(set(u1_locids).intersection(set(u_checkins.locid.unique()))))
        comloc_sum = sum(comloc_nums)
        comloc_nums = [num/comloc_sum for num in comloc_nums]
        return [u1, comloc_nums]

    def cal_user_pairs(self):
        pairs = list(combinations(self.users, 2))
        pairs = pd.DataFrame(pairs, columns=['u1', 'u2'])
        core_num = multiprocessing.cpu_count()
        # 计算用户包括自己的其他用户的共同访问位置的比例
        loc_v = Parallel(n_jobs=core_num)(delayed(self.comloc_meet)(self.checkins[self.checkins.uid == u], u) for u in self.users)
        loc_vector = pd.DataFrame(loc_v, columns=['uid', 'vector'])
        print(loc_vector)
        print("共同访问位置的比例计算完成")
        # 计算用户间共同访问位置余弦相似度
        start = time.time()
        meet_cell = Parallel(n_jobs=core_num)(
            delayed(comloc_similaritys)(loc_vector.loc[loc_vector.uid == pairs.loc[i, 'u1'], 'vector'].values[0],
                                        loc_vector.loc[loc_vector.uid == pairs.loc[i, 'u2'], 'vector'].values[0],
                                        pairs.loc[i, 'u1'], pairs.loc[i, 'u2']) for i in range(len(pairs)))
        end = time.time()
        print(str(end-start))
        pairs_sim_list = pd.DataFrame(meet_cell, columns=['u1', 'u2', 'similarity'])
        print(pairs_sim_list)
        # pairs_sim_list.to_csv("G:/pyfile/relation_protect/src/data/city_data/" + self.city + "_comloc.similarity",
        #                       index=False, header=False)
        return pairs_sim_list

if __name__ == "__main__":
    start = time.time()
    test_case = comloc_similarity()
    checkins = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/test.csv", delimiter="\t", index_col=None)
    test_case.set_checkins(checkins, "1")
    test_case.cal_user_pairs()
    end = time.time()
    print(str(end-start))
