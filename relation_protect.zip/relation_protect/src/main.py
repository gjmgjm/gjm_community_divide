#!/usr/bin/env python  
# encoding: utf-8

""" 
@version: v1.0 
@author: jaculamata 
@license: Apache Licence  
@contact: 819436557@qq.com 
@site: http://blog.csdn.net/hqzxsc2006 
@software: PyCharm 
@file: main.py 
@time: 2019/1/20 16:02 
"""


from utils import data_process, community_divide, grid_divide, security, utility, data_handle
import time
from itertools import  combinations
import pandas as pd
from dls_security import dls_security
import pandas as pd
import time
from grid_divide import grid_divide
from joblib import Parallel, delayed
import multiprocessing
from scipy.special import comb
import numpy as np
from numpy.linalg import norm
from scipy.stats import entropy
from functools import reduce
from operator import add
import math
from itertools import combinations

class Main():

    def __init__(self):
        self.checkins_obf = pd.read_csv("G:/pyfile/relation_protect/src/data/city_data/1.csv", delimiter="\t", index_col=None)
        # self.checkins_obf = self.checkins_obf.values.tolist()
        # self.checkins_obf = grid_divide(self.checkins_obf, 20, [29.816691, -95.456244, 29.679229, -95.286390]).divide_area_by_NN()
        # self.checkins_obf['grid_id'] = self.checkins_obf['grid_id'].astype(int)   # 将原始数据中的grid_id转换成int类型
        print("原始数据读取成功")

    def set_checkins(self, checkins):
        self.checkins = checkins
        # self.checkins.grid_id.apply(float).apply(int)
        print("保护后数据读取成功")

    def entropy(self, probabilities):
        return -reduce(add, map(lambda x: math.log2(x) * x, probabilities))

    def a_security(self):
        locids_uids = self.checkins.groupby(by=['locid', 'uid']).size().reset_index(name='uid_nums')
        locisd_uids_obf = self.checkins_obf.groupby(by=['locid', 'uid']).size().reset_index(name='uid_nums')

        uid_pairs = []  # 用户对
        uid_pairs_fres = []  # 用户对产生的个数
        checkin_cnt = 0
        checkin_chunk_size = int(len(self.checkins_obf.locid.unique()) / 10)
        checkinid = 0
        # 剩下的进行统计
        for locid in self.checkins_obf.locid.unique():
            checkinid += 1
            if checkin_cnt % checkin_chunk_size == 0:  # finished the anonymization of a chunk of checkins打印一部分匿名化的结果
                print('%-3d%% work complete.' % (int(checkin_cnt / checkin_chunk_size) * 10))
            locid_uids = locids_uids[locids_uids.locid == locid].uid.values
            locid_uids_obf = locisd_uids_obf[locisd_uids_obf.locid == locid].uid.values
            common_uids = list(set(locid_uids).intersection(set(locid_uids_obf)))
            if len(common_uids) > 1:
                locid_uid_pairs = list(combinations(common_uids, 2))
                for i in locid_uid_pairs:
                    if set(i) in uid_pairs:
                        uid_pairs_fres[uid_pairs.index(set(i))] += 1
                    else:
                        uid_pairs.append(set(i))
                        uid_pairs_fres.append(1)
            checkin_cnt += 1
        uid_pairs_fres_set = set(uid_pairs_fres)
        uid_pairs_freqs = list(map(lambda x: uid_pairs_fres.count(x), uid_pairs_fres_set))
        freqs_sum = sum(uid_pairs_freqs)
        uid_pairs_freqs = [freq / freqs_sum for freq in uid_pairs_freqs]
        print("a_security:", uid_pairs_freqs)
        q1 = entropy(uid_pairs_freqs)
        print(q1)
        return uid_pairs_freqs

    def cal_security(self, k):
        print(k)
        checkin = pd.read_csv("G:/pyfile/relation_protect/src/data/result_data/simple" + str(k) + "_ano_HCheckins.csv", delimiter="\t",
                              names=["uid", "locid"], header=None)
        self.set_checkins(checkin)
        a = self.a_security()

if __name__ == "__main__":
    # a = community_divide.community_divide()
    start = time.time()
    dls_security = Main()
    for k in [3, 4, 5, 7, 9]:
        dls_security.cal_security(k)
    end = time.time()
    print("总共花的费时间为", str(end - start))